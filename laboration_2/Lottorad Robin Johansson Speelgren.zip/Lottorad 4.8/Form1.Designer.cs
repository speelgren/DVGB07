﻿namespace Lotto
{
    partial class Lottorad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_input_1 = new System.Windows.Forms.TextBox();
            this.textBox_input_2 = new System.Windows.Forms.TextBox();
            this.textBox_input_3 = new System.Windows.Forms.TextBox();
            this.textBox_input_4 = new System.Windows.Forms.TextBox();
            this.textBox_input_5 = new System.Windows.Forms.TextBox();
            this.textBox_input_6 = new System.Windows.Forms.TextBox();
            this.textBox_input_7 = new System.Windows.Forms.TextBox();
            this.textBox_5_correct = new System.Windows.Forms.TextBox();
            this.textBox_6_correct = new System.Windows.Forms.TextBox();
            this.textBox_7_correct = new System.Windows.Forms.TextBox();
            this.textBox_input_counts = new System.Windows.Forms.TextBox();
            this.button_start = new System.Windows.Forms.Button();
            this.label_input_counts = new System.Windows.Forms.Label();
            this.label_5_correct = new System.Windows.Forms.Label();
            this.label_6_correct = new System.Windows.Forms.Label();
            this.label_7_correct = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox_input_1
            // 
            this.textBox_input_1.Location = new System.Drawing.Point(12, 12);
            this.textBox_input_1.Name = "textBox_input_1";
            this.textBox_input_1.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_1.TabIndex = 0;
            // 
            // textBox_input_2
            // 
            this.textBox_input_2.Location = new System.Drawing.Point(72, 12);
            this.textBox_input_2.Name = "textBox_input_2";
            this.textBox_input_2.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_2.TabIndex = 1;
            // 
            // textBox_input_3
            // 
            this.textBox_input_3.Location = new System.Drawing.Point(132, 12);
            this.textBox_input_3.Name = "textBox_input_3";
            this.textBox_input_3.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_3.TabIndex = 2;
            // 
            // textBox_input_4
            // 
            this.textBox_input_4.Location = new System.Drawing.Point(192, 12);
            this.textBox_input_4.Name = "textBox_input_4";
            this.textBox_input_4.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_4.TabIndex = 3;
            // 
            // textBox_input_5
            // 
            this.textBox_input_5.Location = new System.Drawing.Point(252, 12);
            this.textBox_input_5.Name = "textBox_input_5";
            this.textBox_input_5.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_5.TabIndex = 4;
            // 
            // textBox_input_6
            // 
            this.textBox_input_6.Location = new System.Drawing.Point(312, 12);
            this.textBox_input_6.Name = "textBox_input_6";
            this.textBox_input_6.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_6.TabIndex = 5;
            // 
            // textBox_input_7
            // 
            this.textBox_input_7.Location = new System.Drawing.Point(372, 12);
            this.textBox_input_7.Name = "textBox_input_7";
            this.textBox_input_7.Size = new System.Drawing.Size(54, 20);
            this.textBox_input_7.TabIndex = 6;
            // 
            // textBox_5_correct
            // 
            this.textBox_5_correct.Location = new System.Drawing.Point(89, 96);
            this.textBox_5_correct.Name = "textBox_5_correct";
            this.textBox_5_correct.Size = new System.Drawing.Size(54, 20);
            this.textBox_5_correct.TabIndex = 7;
            // 
            // textBox_6_correct
            // 
            this.textBox_6_correct.Location = new System.Drawing.Point(209, 96);
            this.textBox_6_correct.Name = "textBox_6_correct";
            this.textBox_6_correct.Size = new System.Drawing.Size(54, 20);
            this.textBox_6_correct.TabIndex = 8;
            // 
            // textBox_7_correct
            // 
            this.textBox_7_correct.Location = new System.Drawing.Point(329, 96);
            this.textBox_7_correct.Name = "textBox_7_correct";
            this.textBox_7_correct.Size = new System.Drawing.Size(54, 20);
            this.textBox_7_correct.TabIndex = 9;
            // 
            // textBox_input_counts
            // 
            this.textBox_input_counts.Location = new System.Drawing.Point(183, 53);
            this.textBox_input_counts.Name = "textBox_input_counts";
            this.textBox_input_counts.Size = new System.Drawing.Size(114, 20);
            this.textBox_input_counts.TabIndex = 10;
            // 
            // button_start
            // 
            this.button_start.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_start.Location = new System.Drawing.Point(303, 51);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(54, 23);
            this.button_start.TabIndex = 11;
            this.button_start.Text = "Starta";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_clicked);
            // 
            // label_input_counts
            // 
            this.label_input_counts.AutoSize = true;
            this.label_input_counts.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_input_counts.Location = new System.Drawing.Point(78, 55);
            this.label_input_counts.Name = "label_input_counts";
            this.label_input_counts.Size = new System.Drawing.Size(99, 15);
            this.label_input_counts.TabIndex = 12;
            this.label_input_counts.Text = "Antal dragningar:";
            // 
            // label_5_correct
            // 
            this.label_5_correct.AutoSize = true;
            this.label_5_correct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_5_correct.Location = new System.Drawing.Point(46, 99);
            this.label_5_correct.Name = "label_5_correct";
            this.label_5_correct.Size = new System.Drawing.Size(37, 15);
            this.label_5_correct.TabIndex = 13;
            this.label_5_correct.Text = "5 rätt:";
            // 
            // label_6_correct
            // 
            this.label_6_correct.AutoSize = true;
            this.label_6_correct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_6_correct.Location = new System.Drawing.Point(166, 98);
            this.label_6_correct.Name = "label_6_correct";
            this.label_6_correct.Size = new System.Drawing.Size(37, 15);
            this.label_6_correct.TabIndex = 14;
            this.label_6_correct.Text = "6 rätt:";
            // 
            // label_7_correct
            // 
            this.label_7_correct.AutoSize = true;
            this.label_7_correct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_7_correct.Location = new System.Drawing.Point(286, 99);
            this.label_7_correct.Name = "label_7_correct";
            this.label_7_correct.Size = new System.Drawing.Size(37, 15);
            this.label_7_correct.TabIndex = 15;
            this.label_7_correct.Text = "7 rätt:";
            // 
            // Lottorad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(439, 135);
            this.Controls.Add(this.label_7_correct);
            this.Controls.Add(this.label_6_correct);
            this.Controls.Add(this.label_5_correct);
            this.Controls.Add(this.label_input_counts);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.textBox_input_counts);
            this.Controls.Add(this.textBox_7_correct);
            this.Controls.Add(this.textBox_6_correct);
            this.Controls.Add(this.textBox_5_correct);
            this.Controls.Add(this.textBox_input_7);
            this.Controls.Add(this.textBox_input_6);
            this.Controls.Add(this.textBox_input_5);
            this.Controls.Add(this.textBox_input_4);
            this.Controls.Add(this.textBox_input_3);
            this.Controls.Add(this.textBox_input_2);
            this.Controls.Add(this.textBox_input_1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Lottorad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lottorad";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_input_1;
        private System.Windows.Forms.TextBox textBox_input_2;
        private System.Windows.Forms.TextBox textBox_input_3;
        private System.Windows.Forms.TextBox textBox_input_4;
        private System.Windows.Forms.TextBox textBox_input_5;
        private System.Windows.Forms.TextBox textBox_input_6;
        private System.Windows.Forms.TextBox textBox_input_7;
        private System.Windows.Forms.TextBox textBox_5_correct;
        private System.Windows.Forms.TextBox textBox_6_correct;
        private System.Windows.Forms.TextBox textBox_7_correct;
        private System.Windows.Forms.TextBox textBox_input_counts;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Label label_input_counts;
        private System.Windows.Forms.Label label_5_correct;
        private System.Windows.Forms.Label label_6_correct;
        private System.Windows.Forms.Label label_7_correct;
    }
}

